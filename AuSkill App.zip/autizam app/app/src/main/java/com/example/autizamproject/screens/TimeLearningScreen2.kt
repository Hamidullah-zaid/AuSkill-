package com.example.autizamproject.screens

import android.annotation.SuppressLint
import android.speech.tts.TextToSpeech
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.autizamproject.R
import com.example.autizamproject.components.BasicTime
import com.example.autizamproject.components.BottomNavItem
import com.example.autizamproject.components.BottomNavigation
import com.example.autizamproject.components.hoursMinutesPecs
import com.example.autizamproject.components.hoursPecs
import com.example.autizamproject.components.minutesPecs

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun TimeLearningScreen2(tts: TextToSpeech) {

    val selectedItem = remember {
        mutableStateOf(BottomNavItem.Level1)
    }


    val items: Array<BottomNavItem> = BottomNavItem.values()
    items[0].title = stringResource(R.string.basic)
    items[1].title = stringResource(R.string.min)
    items[2].title = stringResource(R.string.hours)
    items[3].title = stringResource(R.string.min_hours)
    items[0].icon = R.drawable.baseline_filter_1_24
    items[1].icon = R.drawable.baseline_filter_2_24


    Scaffold(
        bottomBar = {
            BottomNavigation(selectedItem = selectedItem.value) {
                selectedItem.value = it
            }
        },
    ) {

        when (selectedItem.value) {
            BottomNavItem.Level1 -> SetValues(
                tts,
                stringResource(R.string.learning_basics), BasicTime
            )

            BottomNavItem.Level2 -> SetValues(
                tts,
                stringResource(R.string.learning_minutes), minutesPecs
            )

            BottomNavItem.Level3 -> SetValues(
                tts,
                stringResource(R.string.learning_hours), hoursPecs
            )

            BottomNavItem.Level4 -> SetValues(
                tts,
                stringResource(id = R.string.learning_minutes_hours),
                hoursMinutesPecs
            )
        }
    }
}

@Composable
fun SetValues(tts: TextToSpeech, str: String, items: List<Pair<String, Int>>) {
    Column(Modifier.background(Color(0xFFEBEBCB))) {
        Text(
            text = str,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.headlineLarge,
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        )

        AnimatedViewPagerToilet(
            modifier = Modifier
                .background(Color(0xFFEBEBCB))
                .fillMaxWidth(),
            tts,
            pecsList = items
        )
    }
}


