package com.example.autizamproject.components

import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.autizamproject.MyApp.Companion.context
import com.example.autizamproject.R

@Composable
fun BottomNavigation(
    selectedItem: BottomNavItem,
    items: Array<BottomNavItem> = BottomNavItem.values(),
    onItemSelected: (BottomNavItem) -> Unit
) {

    NavigationBar {
        items.forEach { item ->
            AddItem(
                screen = item,
                selected = item == selectedItem,
                onClick = { onItemSelected(item) }
            )
        }
    }
}


@Composable
fun RowScope.AddItem(
    screen: BottomNavItem,
    selected: Boolean,
    onClick: () -> Unit
) {
    NavigationBarItem(
        label = {
            Text(text = screen.title)
        },
        icon = {
            Icon(
                painterResource(id = screen.icon),
                contentDescription = screen.title,
                modifier = Modifier.size(24.dp)
            )
        },
        selected = selected,
        alwaysShowLabel = true,
        onClick = onClick,
    )
}


enum class BottomNavItem(var title: String, var icon: Int) {
    Level1(context.getString(R.string.level_1), R.drawable.baseline_filter_1_24),
    Level2(context.getString(R.string.level_2), R.drawable.baseline_filter_2_24),
    Level3(context.getString(R.string.level_3), R.drawable.baseline_filter_3_24),
    Level4(context.getString(R.string.level_4), R.drawable.baseline_filter_4_24),
}
