package com.example.autizamproject.viewmodels

import android.util.Log
import androidx.compose.runtime.mutableStateMapOf
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

class VideoTitleViewModel : ViewModel() {
    private val videoTitles = mutableStateMapOf<String, String>()

    fun getTitle(videoId: String): String {
        return videoTitles[videoId] ?: ""
    }

    suspend fun fetchAndSaveTitle(videoId: String) {
        getTitleQuietly(videoId) {
            videoTitles[videoId] = it
        }

    }

    suspend fun getTitleQuietly(id: String?, call: (String) -> Unit) {
        withContext(Dispatchers.IO) {

            try {
                val url = "https://www.youtube.com/watch?v=$id"

                val client = OkHttpClient()
                val request = Request.Builder()
                    .url("https://noembed.com/embed?url=$url&format=json")
                    .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        println("Failed to retrieve data")
                        call.invoke("Error")
                    }

                    val responseData = response.body?.string()
                    val data = JSONObject(responseData)
                    val title = data.getString("title")
                    Log.i("VideoData", "getTitleQuietly: $title")
                    call.invoke(title)
                }
            } catch (e: Exception) {
                call.invoke(e.toString())
                e.printStackTrace()
            }
        }

    }
}


