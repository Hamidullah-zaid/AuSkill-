package com.example.autizamproject.screens

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.autizamproject.R
import com.example.autizamproject.components.ComposeLottieAnimation
import com.example.autizamproject.components.toiletPecs
import kotlin.random.Random

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun WashroomActivityScreen(textToSpeech: TextToSpeech) {
    // Replace this with your array of images and titles
    Scaffold(
        content = {
            WashroomGameScreen(textToSpeech)
        }
    )
}

@Composable
fun WashroomGameScreen(tts: TextToSpeech) {
    val context = LocalContext.current

    var correctColor by remember { mutableIntStateOf(randomCard()) }
    var wrongColor by remember { mutableIntStateOf(randomCard()) }
    var showAnimation by remember { mutableStateOf(false) }
    var animId by remember { mutableIntStateOf(R.raw.sucess_anim) }

    while (wrongColor == correctColor) {
        wrongColor = randomCard()
        showAnimation = false
    }

    Box {


        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFEBEBCB))
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val chose = stringResource(id = R.string.choose)

            val chosenColorName = toiletPecs.find { it.second == correctColor }?.first ?: "___"
            Text("$chose $chosenColorName", style = MaterialTheme.typography.headlineLarge)

            if (!showAnimation)
                tts.speak(
                    "$chose $chosenColorName",
                    TextToSpeech.QUEUE_FLUSH,
                    null,
                    null
                )


            Spacer(modifier = Modifier.height(16.dp))
            val goodJob = stringResource(id = R.string.good_job_you_have_chose_correct_one)
            val wrong = stringResource(id = R.string.ohh_no_you_chose_wrong_try_again)
            val colorSelected: (Int) -> Unit = { color ->
                if (color == correctColor) {
                    showAnimation = true
                    animId = R.raw.sucess_anim
                    tts.speak(
                        goodJob,
                        TextToSpeech.QUEUE_FLUSH,
                        null,
                        null
                    )


                    Handler(Looper.getMainLooper()).postDelayed({
                        showAnimation = false
                        correctColor = randomCard()
                    }, 2500)
                } else {
                    showAnimation = true
                    animId = R.raw.try_again
                    tts.speak(
                        wrong,
                        TextToSpeech.QUEUE_FLUSH,
                        null,
                        null
                    )

                    Handler(Looper.getMainLooper()).postDelayed({
                        showAnimation = false
                    }, 2500)
                }

            }
            val ran = Random.nextBoolean()
            WashroomCard(color = if (ran) correctColor else wrongColor, colorSelected)

            Spacer(modifier = Modifier.height(40.dp))

            WashroomCard(color = if (!ran) correctColor else wrongColor, colorSelected)
        }

        if (showAnimation) {
            ComposeLottieAnimation(Modifier.fillMaxSize(), animId)
        }
    }
}


@Composable
fun WashroomCard(color: Int, onClick: (Int) -> Unit) {
    Card(
        modifier = Modifier
            .size(200.dp)
            .clickable { onClick(color) }
    ) {

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFCFC8AE.toInt())),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = color),
                contentDescription = "",
                contentScale = ContentScale.FillWidth,
                modifier = Modifier
                    .padding(bottom = 50.dp)
                    .fillMaxSize()

            )

        }
    }
}

fun randomCard(): Int {
    val randomIndex = Random.nextInt(toiletPecs.size)
    return toiletPecs[randomIndex].second
}


