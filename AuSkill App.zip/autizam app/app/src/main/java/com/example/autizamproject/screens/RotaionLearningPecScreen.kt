package com.example.autizamproject.screens

import android.annotation.SuppressLint
import android.speech.tts.TextToSpeech
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.res.stringResource
import com.example.autizamproject.R
import com.example.autizamproject.components.BottomNavItem
import com.example.autizamproject.components.BottomNavigation
import com.example.autizamproject.components.antiClockWiseSpinner
import com.example.autizamproject.components.clockWiseSpinner
import com.example.autizamproject.components.degree
import com.example.autizamproject.components.hoursMinutesPecs
import com.example.autizamproject.components.hoursPecs
import com.example.autizamproject.components.minutesPecs

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun RotationLearningPecScreen(tts: TextToSpeech) {
    // Replace this with your array of images and titles

    val items: Array<BottomNavItem> = BottomNavItem.values()
    val firstTwoItems: Array<BottomNavItem> = items.take(3).toTypedArray()

    firstTwoItems[0].apply {
        title = stringResource(R.string.degree)
        icon = R.drawable.angle_24
    }


    firstTwoItems[1].apply {
        title = stringResource(R.string.clock_wise)
        icon = R.drawable.baseline_rotate_right_24
    }
    firstTwoItems[2].apply {
        title = stringResource(R.string.anti_clock_wise)
        icon = R.drawable.baseline_rotate_left_24
    }

    val selectedItem = remember {
        mutableStateOf(BottomNavItem.Level1)
    }

    Scaffold(
        bottomBar = {
            BottomNavigation(selectedItem = selectedItem.value, firstTwoItems) {
                selectedItem.value = it
            }
        },
    ) {

        when (selectedItem.value) {
            BottomNavItem.Level1 -> SetValues(tts, stringResource(R.string.learning_angles), degree)

            BottomNavItem.Level2 -> SetValues(
                tts,
                stringResource(R.string.learning_clock_wise_rotation), clockWiseSpinner
            )

            BottomNavItem.Level3 -> SetValues(
                tts,
                stringResource(R.string.learning_anti_clock_wise_rotation),
                antiClockWiseSpinner
            )

            BottomNavItem.Level4 -> SetValues(
                tts,
                stringResource(R.string.learning_minutes_hours), hoursMinutesPecs
            )
        }
    }
}
