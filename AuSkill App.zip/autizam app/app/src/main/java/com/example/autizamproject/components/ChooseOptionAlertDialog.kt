package com.example.autizamproject.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.autizamproject.R
import com.example.autizamproject.ui.theme.dialogueBg

@Composable
fun ChooseOptionAlertDialog(
    onOptionSelected: (Option) -> Unit,
    onCancel: () -> Unit
) = AlertDialog(
    onDismissRequest = onCancel,
    title = {
        Text(
            text = stringResource(R.string.pick_what_you_like),
            style = MaterialTheme.typography.headlineSmall
        )
    },
    text = {
        Column(
            modifier = Modifier
                .fillMaxWidth()

                .padding(16.dp),

            ) {
            TextButton(
                onClick = {
                    onOptionSelected(Option.VOCABULARY)
                },
                modifier = Modifier
                    .padding(4.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.learning_pec),
                    contentDescription = "", modifier = Modifier.size(60.dp)
                )

                Text(text = stringResource(R.string.learning_from_pecs))
            }
            TextButton(
                onClick = {
                    onOptionSelected(Option.ACTIVITY)
                },
                modifier = Modifier
                    .padding(4.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.learning_activity),
                    contentDescription = "", modifier = Modifier.size(60.dp)
                )

                Text(text = stringResource(R.string.learning_from_activity))
            }

            TextButton(
                onClick = {
                    onOptionSelected(Option.VIDEO)
                },
                modifier = Modifier
                    .padding(4.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.learning_video),
                    contentDescription = "",
                    modifier = Modifier.size(60.dp)
                )

                Text(text = stringResource(R.string.learning_from_video))
            }
        }
    },
    confirmButton = {},
    dismissButton = {
        TextButton(
            onClick = onCancel
        ) {
            Text(text = stringResource(id = R.string.cancel))
        }
    },
    containerColor = dialogueBg
)

enum class Option {
    VOCABULARY,
    ACTIVITY,
    VIDEO
}
