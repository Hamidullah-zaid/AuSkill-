package com.example.autizamproject.routes

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Login : Screen("login")
    object Signup : Screen("signup")
    object Home : Screen("home")
    object TimeLearning : Screen("time_learning")
    object TimeActivity : Screen("time_activity")
    object TimeLearning2 : Screen("time_learning2")
    object RotationLearning : Screen("rotation_learning")
    object RotationPecLearning : Screen("rotation_learning_pec")
    object ColorsLearning : Screen("colors_learning")
    object ColorsActivity : Screen("colors_activity")
    object ToiletLearning : Screen("washroom_learning")
    object ToiletActivity : Screen("washroom_activity")
    object VideoActivity : Screen("video_activity/{id}") {
        fun routeWithId(id: String): String {
            return "video_activity/$id"
        }
    }

}