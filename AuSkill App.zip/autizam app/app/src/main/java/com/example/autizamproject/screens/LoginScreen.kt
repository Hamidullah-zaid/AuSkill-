package com.example.autizamproject.screens

import android.annotation.SuppressLint
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.autizamproject.R
import com.example.autizamproject.routes.Screen
import com.example.autizamproject.viewmodels.SignupViewModel

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(navController: NavHostController) {
    val signupViewModel: SignupViewModel = viewModel()

    val context = LocalContext.current
    Scaffold(
        content = {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Your logo here
                // Image(logo, "Logo")

                Image(
                    painter = painterResource(id = R.drawable.logo),
                    contentDescription = stringResource(R.string.logo),
                    modifier = Modifier.size(90.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = signupViewModel.email,
                    onValueChange = { signupViewModel.email = it },
                    label = { Text(stringResource(R.string.email)) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    isError = !signupViewModel.isEmailValid.value!!
                )
                if (!signupViewModel.isEmailValid.value) {
                    Text(
                        text = stringResource(R.string.invalid_email_format),
                        color = Color.Red,
                        modifier = Modifier.padding(start = 16.dp)
                    )
                }



                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = signupViewModel.password,
                    onValueChange = { signupViewModel.password = it },
                    label = { Text(stringResource(R.string.password)) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    isError = !signupViewModel.isPasswordMatch.value
                )
                if (!signupViewModel.isPasswordMatch.value) {
                    Text(
                        text = stringResource(R.string.enter_valid_password),
                        color = Color.Red,
                        modifier = Modifier.padding(start = 16.dp)
                    )
                }



                Spacer(modifier = Modifier.height(16.dp))


                OutlinedButton(
                    onClick = {
                        signupViewModel.loginUser(
                            onSuccess = {
                                navController.navigate(Screen.Home.route) {
                                    navController.popBackStack()
                                    popUpTo(Screen.Home.route) {
                                        inclusive = true
                                    }
                                }
                            },
                            onFailure = { errorMessage ->
                                // Handle failure and show an error message
                                Toast.makeText(context, errorMessage, Toast.LENGTH_SHORT).show()
                                Log.e("SignupScreen", errorMessage)
                            }
                        )// Hide the keyboard after sign-in button click
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = stringResource(R.string.sign_in))
                }


                Button(onClick = {
                    navController.navigate(Screen.Signup.route)
                }) {
                    Text(text = stringResource(R.string.sign_up))
                }

            }
        }
    )
}


