package com.example.autizamproject.components

import com.example.autizamproject.MyApp.Companion.context
import com.example.autizamproject.R

val colors = listOf(
    context.getString(R.string.red) to 0xFFFF0000.toInt(),
    context.getString(R.string.blue) to 0xFF0000FF.toInt(),
    context.getString(R.string.yellow) to 0xFFFFFF00.toInt(),
    context.getString(R.string.green) to 0xFF00FF00.toInt(),
    context.getString(R.string.white) to 0xFFFFFFFF.toInt(),
    context.getString(R.string.orange) to 0xFFFFA500.toInt(),
    context.getString(R.string.purple) to 0xFF800080.toInt(),
    context.getString(R.string.pink) to 0xFFFFC0CB.toInt(),
    context.getString(R.string.brown) to 0xFFA52A2A.toInt(),
    context.getString(R.string.cyan) to 0xFF00FFFF.toInt(),
    context.getString(R.string.magenta) to 0xFFFF00FF.toInt(),
    context.getString(R.string.lime) to 0xFF00FF00.toInt(),
    context.getString(R.string.teal) to 0xFF008080.toInt(),
    context.getString(R.string.indigo) to 0xFF4B0082.toInt(),
    context.getString(R.string.silver) to 0xFFC0C0C0.toInt()
)


val toiletPecs = listOf(
    context.getString(R.string.goto_washroom) to R.drawable.go_to_washroom,
    context.getString(R.string.pull_down_paint) to R.drawable.pull_down_pants,
    context.getString(R.string.set_on_toilet) to R.drawable.set_on_toilet,
    context.getString(R.string.use_toilet_paper) to R.drawable.use_toilet_paper,
    context.getString(R.string.pull_up_paint) to R.drawable.pull_up_pants,
    context.getString(R.string.flush) to R.drawable.flush,
    context.getString(R.string.wash_hands) to R.drawable.wash_hands,

    )


val minutesPecs = listOf(
    context.getString(R.string.minute_zero) to R.drawable.hours_00_and_minutes_00,
    context.getString(R.string._5_minutes) to R.drawable.minutes_05,
    context.getString(R.string._10_minutes) to R.drawable.minutes_10,
    context.getString(R.string._15_minutes) to R.drawable.minutes_15,
    context.getString(R.string._20_minutes) to R.drawable.minutes_20,
    context.getString(R.string._25_minutes) to R.drawable.minutes_25,
    context.getString(R.string._30_minutes) to R.drawable.minutes_30,
    context.getString(R.string._35_minutes) to R.drawable.minutes_35,
    context.getString(R.string._40_minutes) to R.drawable.minutes_40,
    context.getString(R.string._45_minutes) to R.drawable.minutes_45,
    context.getString(R.string._50_minutes) to R.drawable.minutes_50,
    context.getString(R.string._55_minutes) to R.drawable.minutes_55,
    context.getString(R.string._60_minutes) to R.drawable.minutes_60,
)


val BasicTime = listOf(
    "" to R.drawable.analogue_clock_one,
    context.getString(R.string.hours_hand) to R.drawable.hours_hand_two,
    context.getString(R.string.minutes_hand) to R.drawable.minutes_hand_three,
    context.getString(R.string.hours_and_minutes_hands) to R.drawable.minutes_hours_hands_four,
    "" to R.drawable.hours_minutes_digital_five,
    context.getString(R.string.zero_hours_5_minutes) to R.drawable.minutes_hours_hands_digital_six,
    "" to R.drawable.digital_clock_seven,
    "" to R.drawable.hour___60_minutes_eight,
)


val BasicTimeText = listOf(
    0 to context.getString(R.string.the_short_hand_tell_the_hours_and_the_long_hand_tells_the_minutes),
    4 to context.getString(R.string.hour_and_minutes_separated_by_colons),
    6 to context.getString(R.string.the_left_side_of_the_colon_show_hours_and_the_right_side_of_the_colons_show_minutes),
    7 to context.getString(R.string._1_hour_is_equal_to_60_minutes)
)

val hoursPecs = listOf(
    context.getString(R.string.hour_zero) to R.drawable.hours_00_and_minutes_00,
    context.getString(R.string.hour_1) to R.drawable.hours_01,
    context.getString(R.string.hour_2) to R.drawable.hours_02,
    context.getString(R.string.hour_3) to R.drawable.hours_03,
    context.getString(R.string.hour_4) to R.drawable.hours_04,
    context.getString(R.string.hour_5) to R.drawable.hours_05,
    context.getString(R.string.hour_6) to R.drawable.hours_06,
    context.getString(R.string.hour_7) to R.drawable.hours_07,
    context.getString(R.string.hour_8) to R.drawable.hours_08,
    context.getString(R.string.hour_9) to R.drawable.hours_09,
    context.getString(R.string.hour_10) to R.drawable.hours_10,
    context.getString(R.string.hour_11) to R.drawable.hours_11,
    context.getString(R.string.hour_12) to R.drawable.hours_12
)


val hoursMinutesPecs = listOf(
    context.getString(R.string.hour_zero_minute_zero) to R.drawable.hours_00_and_minutes_00,
    context.getString(R.string.hour_1_minute_zero) to R.drawable.hours_01_minute_00,
    context.getString(R.string.hour_1_minute_5) to R.drawable.hours_minuts_01_05,
    context.getString(R.string.hour_1_minute_10) to R.drawable.hours_minuts_01_10,
    context.getString(R.string.hour_1_minute_15) to R.drawable.hours_minuts_01_15,
    context.getString(R.string.hour_1_minute_20) to R.drawable.hours_minuts_01_20,
    context.getString(R.string.hour_1_minute_25) to R.drawable.hours_minuts_01_25,
    context.getString(R.string.hour_1_minute_30) to R.drawable.hours_minuts_01_30,
    context.getString(R.string.hour_1_minute_35) to R.drawable.hours_minuts_01_35,
    context.getString(R.string.hour_1_minute_40) to R.drawable.hours_minuts_01_40,
    context.getString(R.string.hour_1_minute_45) to R.drawable.hours_minuts_01_45,
    context.getString(R.string.hour_1_minute_50) to R.drawable.hours_minuts_01_50,
    context.getString(R.string.hour_1_minute_55) to R.drawable.hours_minuts_01_55,
    context.getString(R.string.hour_2_minute_00) to R.drawable.hours_minuts_02_00,

    )

val clockWiseSpinner = listOf(
    context.getString(R.string.clock_wise_0_degree) to R.drawable.clock_wise_spinner,
    context.getString(R.string.clock_wise_90_degree) to R.drawable.clock_wise_90_spinner,
    context.getString(R.string.clock_wise_180_degree) to R.drawable.clock_wise_180_spinner,
    context.getString(R.string.clock_wise_270_degree) to R.drawable.clock_wise_270_spinner,
    context.getString(R.string.clock_wise_360_degree) to R.drawable.clock_wise_360_spinner,
)


val degree = listOf(
    context.getString(R.string.zero_degree) to R.drawable.match_stick_0,
    context.getString(R.string._45_degree) to R.drawable.match_stick_45,
    context.getString(R.string._90_degree) to R.drawable.match_stick_90,
    context.getString(R.string._180_degree) to R.drawable.match_stick_180,
    context.getString(R.string._270_degree) to R.drawable.match_stick_270,
    context.getString(R.string._360_degree) to R.drawable.match_stick_360,
)

val antiClockWiseSpinner = listOf(
    context.getString(R.string.anti_clock_wise_0_degree) to R.drawable.anti_clock_spinner,
    context.getString(R.string.anti_clock_wise_90_degree) to R.drawable.anti_clock_90_spinner_,
    context.getString(R.string.anti_clock_wise_180_degree) to R.drawable.anti_clock_180_spinner_,
    context.getString(R.string.anti_clock_wise_270_degree) to R.drawable.anti_clock_270_spinner_,
    context.getString(R.string.anti_clock_wise_360_degree) to R.drawable.anti_clock_360_spinner_,
)


val toiletVideos = listOf(
    "UCjAy_ny31Q",
    "LH7KPTVuc6M",
    "iKMGT4tt16c",
    "LrrpnP_9qAM",
    "f5qCCrpCGEk",
    "AkTRISf3LZQ",
    "_RvLphH5uLI",
    "ocCDaneFaeE",
    "WX7LThDab2s",
    "423LthRE09o"
)


val colorsVideos = listOf(

    "DwEmhQOFAqY",
    "rytQEIJnx0s",
    "TIWjdyrox8k",
    "0Dz6TrZGJyA",
    "E1mW7nqC8Ck",
    "qE5xA0Irm_Q",
    "xcXKEATJSm4",
    "rytQEIJnx0s",
    "Egsmiz_Y2OM",
    "XoYvSALk5so",

    )


val timeVideos = listOf(

    "g7mQGSx5lwY&list", "FNEUWVk0OXI",
    "_lulVemIKVU",
    "oeBjL_P6HgU",
    "axydlvSo_DI",
    "ehM_C6mLIPY",
    "fuNakY51YpM",
    "utV2HYr3p-g",
    "Bqo6-DMzdB8",
    "9p_Ca_Yb0zQ",

    )


val rotationVideos = listOf(
    "uDtUs-33NaQ",
    "gNfJGEuePKo",
    "4edRv0O2hno",
    "LSsv5lEvjuk",
    "0lqrO_F0vyg",
    "ab_e1WxIIh4",
    "NUFuXHAs5SA",
    "xLlzH_dSK-E",
    "g2aDl3Z8uz4",
    "CwRde72adQY"
)