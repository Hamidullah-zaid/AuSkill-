package com.example.autizamproject.components

import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.rememberLottieComposition
import com.example.autizamproject.R

@Composable
fun ComposeLottieAnimation(modifier: Modifier, animId: Int) {


    val composition by rememberLottieComposition(LottieCompositionSpec.RawRes(animId))

    LottieAnimation(
        modifier = modifier.size(70.dp),
        composition = composition,
        iterations = 1,
    )
}