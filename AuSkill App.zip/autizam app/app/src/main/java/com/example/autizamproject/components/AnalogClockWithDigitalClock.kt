/*package com.example.autizamproject.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Matrix
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.lang.Math.atan2
import java.lang.Math.cos
import java.lang.Math.sin
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun AnalogClockWithDigitalClock() {
    var hourAngle by remember { mutableStateOf(0f) }
    var minuteAngle by remember { mutableStateOf(0f) }
    var digitalTime by remember { mutableStateOf("12:00 AM") }

    val clockBackgroundColor = Color.Red
    val hourHandColor = Color.Blue

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AnalogClock(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .background(clockBackgroundColor),
                hourAngle = hourAngle,
                minuteAngle = minuteAngle,
                hourHandColor = hourHandColor,
                onHourHandDrag = { angle ->
                    hourAngle = angle
                    updateDigitalTime(hourAngle, minuteAngle)
                },
                onMinuteHandDrag = { angle ->
                    minuteAngle = angle
                    updateDigitalTime(hourAngle, minuteAngle)
                }
            )
            Spacer(modifier = Modifier.height(16.dp))
            BasicTextField(
                value = digitalTime,
                onValueChange = { digitalTime = it },
                textStyle = TextStyle(fontSize = 24.sp),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            )
        }
    }
}*//*

*/
/*
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun AnalogClock(
    modifier: Modifier = Modifier,
    hourAngle: Float,
    minuteAngle: Float,
    hourHandColor: Color,
    onHourHandDrag: (Float) -> Unit,
    onMinuteHandDrag: (Float) -> Unit
) {
    val clockCenter = Offset(180f, 180f)
    val clockRadius = 160f
    val hourHandLength = 100f
    val minuteHandLength = 140f

    Canvas(
            modifier = modifier
                .pointerInput(Unit)
                .pointerInteropFilter { event ->
                    val offsetX = event.x
                    val offsetY = event.y

                    val angle = calculateAngle(Offset(offsetX, offsetY), clockCenter)
                    when {
                        event.pointerCount == 1 && event.downTime && isWithinHourHand(angle, hourAngle) -> {
                            onHourHandDrag(angle)
                            true
                        }
                        event.pointerCount == 1 && event.currentEvent.down && isWithinMinuteHand(angle, minuteAngle) -> {
                            onMinuteHandDrag(angle)
                            true
                        }
                        else -> false
                    }
                }
    ) {
        drawCircle(
            color = Color.White,
            center = clockCenter,
            radius = clockRadius,
        )

        // Draw the clock face
        for (i in 0 until 12) {
            val angle = i * (360f / 12)
            val markerStart = Offset(
                x = clockCenter.x + clockRadius * 0.9f * cos(Math.toRadians(angle.toDouble()).toFloat()),
                y = clockCenter.y + clockRadius * 0.9f * sin(Math.toRadians(angle.toDouble()).toFloat())
            )
            val markerEnd = Offset(
                x = clockCenter.x + clockRadius * cos(Math.toRadians(angle.toDouble()).toFloat()),
                y = clockCenter.y + clockRadius * sin(Math.toRadians(angle.toDouble()).toFloat())
            )
            drawLine(
                color = Color.White,
                start = markerStart,
                end = markerEnd,
                strokeWidth = 4f
            )
        }

        // Draw hour hand
        val hourHandEnd = Offset(
            x = clockCenter.x + hourHandLength * cos(Math.toRadians(hourAngle.toDouble()).toFloat()),
            y = clockCenter.y + hourHandLength * sin(Math.toRadians(hourAngle.toDouble()).toFloat())
        )
        drawLine(
            color = hourHandColor,
            start = clockCenter,
            end = hourHandEnd,
            strokeWidth = 8f
        )

        // Draw minute hand
        val minuteHandEnd = Offset(
            x = clockCenter.x + minuteHandLength * cos(Math.toRadians(minuteAngle.toDouble()).toFloat()),
            y = clockCenter.y + minuteHandLength * sin(Math.toRadians(minuteAngle.toDouble()).toFloat())
        )
        drawLine(
            color = Color.White,
            start = clockCenter,
            end = minuteHandEnd,
            strokeWidth = 4f
        )

        // Fill the inner portion of the clock with red color
        drawArc(
            color = Color.Red,
            startAngle = -90f,
            sweepAngle = hourAngle - 90f,
            useCenter = true,
            topLeft = Offset(clockCenter.x - clockRadius, clockCenter.y - clockRadius),
            size = Size(clockRadius * 2, clockRadius * 2)
        )
    }
}*//*


fun calculateAngle(point: Offset, center: Offset): Float {
    val angle = Math.toDegrees(atan2(point.y - center.y, point.x - center.x).toDouble())
    return if (angle < 0) (angle + 360).toFloat() else angle.toFloat()
}

fun updateDigitalTime(hourAngle: Float, minuteAngle: Float) {
    val hour = (hourAngle / 360 * 12).toInt()
    val minute = (minuteAngle / 360 * 60).toInt()
    val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
    val calendar = Calendar.getInstance()
    calendar.set(Calendar.HOUR_OF_DAY, hour)
    calendar.set(Calendar.MINUTE, minute)
    val digitalTime = timeFormat.format(calendar.time)
    // Update the digital time here
}
*/
