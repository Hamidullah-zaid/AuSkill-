package com.example.autizamproject.components

import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.MotionEvent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.autizamproject.R
import com.example.autizamproject.screens.toDegrees
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/*
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun RotatableCircle() {
    var rotationState by remember { mutableStateOf(0f) }

    Canvas(
        modifier = Modifier
            .size(300.dp)
            .padding(16.dp)
            .pointerInteropFilter { event ->
                val centerX = 300 / 2
                val centerY = 300 / 2

                if (event.action == MotionEvent.ACTION_MOVE) {
                    val startX = centerX
                    val startY = centerY - 100 // Adjust the handle length as needed
                    val endX = event.x
                    val endY = event.y

                    val angle = atan2(endY - centerY, endX - centerX).toDegrees()
                    rotationState = angle
                }

                true
            }
    ) {
        val centerX = size.width / 2
        val centerY = size.height / 2
        val radius = minOf(centerX, centerY) - 20

        // Draw the circle
        drawCircle(
            color = Color.Gray,
            center = Offset(centerX, centerY),
            radius = radius,
        )

        // Draw the handle
        val handleLength = 350f // Adjust the handle length as needed
        val handleAngle = rotationState.toRadians()

        val handleEndX = centerX + handleLength / 2 * Math.cos(handleAngle).toFloat()
        val handleEndY = centerY + handleLength / 2 * Math.sin(handleAngle).toFloat()

        drawLine(
            color = Color.Blue,
            start = Offset(centerX, centerY),
            end = Offset(handleEndX, handleEndY),
            strokeWidth = 10f
        )

        drawCircle(
            color = Color.Blue,
            center = Offset(handleEndX, handleEndY),
            radius = 25f
        )

        // Display the rotation value
        drawIntoCanvas {
            it.nativeCanvas.drawText(
                String.format("%.2f°", rotationState),
                16f,
                16f + 20.dp.toPx(),
                android.graphics.Paint().apply {
                    textSize = 20.dp.toPx()
                    color = Color.Black.toArgb()
                }
            )
        }
    }
}

fun Double.toDegrees(): Float {
    return (this * 180f / Math.PI).toFloat()
}

fun Float.toRadians(): Double {
    return Math.toRadians(this.toDouble())
}
*/




@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun RotatableCircle(textToSpeech: TextToSpeech) {
    var timeNow = ""
    val handleLength = 450f // Adjust the handle length as needed
    var isDragging by remember { mutableStateOf(false) } // Track whether dragging is happening

    var rotationState by remember { mutableFloatStateOf(0f) }
    var handleEndX = 0f
    var handleEndY = 0f

    var isDragging1 by remember { mutableStateOf(false) } // Track whether dragging is happening
    var rotationState1 by remember { mutableFloatStateOf(90f) }
    var handleEndX1 = 0f
    var handleEndY1 = 0f

    val painter = painterResource(id = R.drawable.clock_face)
    Canvas(
        modifier = Modifier
            .size(300.dp)
            .padding(16.dp)
            .pointerInteropFilter { event ->
                val centerX = 300 / 2
                val centerY = 300 / 2


                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        val touchX = event.x
                        val touchY = event.y

                        // Calculate the distance between the touch coordinates and the center of the circle
                        val distance = Math
                            .sqrt(
                                Math.pow((touchX - handleEndX).toDouble(), 2.0) +
                                        Math.pow((touchY - handleEndY).toDouble(), 2.0)
                            )
                            .toFloat()

                        val distance1 = Math
                            .sqrt(
                                Math.pow((touchX - handleEndX1).toDouble(), 2.0) +
                                        Math.pow((touchY - handleEndY1).toDouble(), 2.0)
                            )
                            .toFloat()

                        val circleRadius = 50f// The radius of the blue circle

                        if (distance <= circleRadius)
                            isDragging = true
                        else if (distance1 <= circleRadius)
                            isDragging1 = true
                    }

                    MotionEvent.ACTION_MOVE -> {
                        Log.i("DragTrack", "RotatableCircle: $isDragging")
                        if (isDragging) {
                            val angle = atan2(event.y - centerY, event.x - centerX).toDegrees()
                            rotationState = angle
                        } else if (isDragging1) {
                            val angle = atan2(event.y - centerY, event.x - centerX).toDegrees()
                            rotationState1 = angle
                        }

                    }

                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        isDragging = false
                        isDragging1 = false

                        textToSpeech.speak(
                            timeNow,
                            TextToSpeech.QUEUE_FLUSH,
                            null,
                            null
                        )
                    }
                }

                true
            }
    ) {
        val centerX = size.width / 2
        val centerY = size.height / 2
        val radius = minOf(centerX, centerY)

        // Draw the circle
        drawCircle(
            color = Color.Gray,
            center = Offset(centerX, centerY),
            radius = radius,
        )


        with(painter) {
            draw(size = Size(size.width, size.height))
        }

        // Draw the handle
        val handleAngle = rotationState.toRadians()
        val handleAngle1 = rotationState1.toRadians()

        handleEndX = centerX + handleLength / 2 * cos(handleAngle).toFloat()
        handleEndY = centerY + handleLength / 2 * sin(handleAngle).toFloat()


        handleEndX1 = centerX + (handleLength - 100) / 2 * cos(handleAngle1).toFloat()
        handleEndY1 = centerY + (handleLength - 100) / 2 * sin(handleAngle1).toFloat()

        drawLine(
            color = Color.White,
            start = Offset(centerX, centerY),
            end = Offset(handleEndX, handleEndY),
            strokeWidth = 10f
        )




        drawCircle(
            color = Color.White,
            center = Offset(handleEndX, handleEndY),
            radius = 15f
        )


        drawLine(
            color = Color.Black,
            start = Offset(centerX, centerY),
            end = Offset(handleEndX1, handleEndY1),
            strokeWidth = 10f
        )

        drawCircle(
            color = Color.Black,
            center = Offset(handleEndX1, handleEndY1),
            radius = 15f
        )

        drawCircle(
            color = Color.LightGray,
            center = Offset(centerX, centerY),
            radius = 15f
        )


        var rotationDegrees =
            (450 + rotationState) % 360 // Adjust 450 to match your initial rotation
        if (rotationDegrees < 0) {
            rotationDegrees += 360
        }
        val minutes = (rotationDegrees / 360f) * 60f
        val formattedMinutes = minutes.roundToInt().toString()


        var rotationDegreesH =
            (450 + rotationState1) % 360 // Adjust 450 to match your initial rotation
        if (rotationDegreesH < 0) {
            rotationDegreesH += 360
        }
        val hours = (rotationDegreesH / 360f) * 12f
        var formattedHours = hours.roundToInt().toString()
        if (hours.toInt() == 0)
            formattedHours = "12"

        timeNow = "$formattedHours Hours : $formattedMinutes Minutes"

// Display the rotation value
        drawIntoCanvas {
            it.nativeCanvas.drawText(
                timeNow,
                40f,
                size.height + 100.dp.toPx(),
                android.graphics.Paint().apply {
                    textSize = 26.dp.toPx()
                    color = Color.Black.toArgb()
                }
            )
        }

        /*   // Display the rotation value
           drawIntoCanvas {
               it.nativeCanvas.drawText(
                   formattedMinutes,
                   (size.width - 50) / 2,
                   size.height + 100.dp.toPx(),
                   android.graphics.Paint().apply {
                       textSize = 20.dp.toPx()
                       color = Color.Black.toArgb()
                   }
               )
           }*/
    }
}

fun Double.toDegrees(): Float {
    return (this * 180f / Math.PI).toFloat()
}

fun Float.toRadians(): Double {
    return Math.toRadians(this.toDouble())
}
