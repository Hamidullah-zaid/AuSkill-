package com.example.autizamproject.screens

import android.annotation.SuppressLint
import android.app.Activity
import android.app.LocaleManager
import android.content.res.Resources
import android.os.Build
import android.os.LocaleList
import android.preference.PreferenceManager
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import androidx.navigation.NavHostController
import com.example.autizamproject.MyApp.Companion.context
import com.example.autizamproject.R
import com.example.autizamproject.components.ImageCard
import com.example.autizamproject.components.Option
import com.example.autizamproject.components.Spinner
import com.example.autizamproject.models.ImageWithTitle
import com.example.autizamproject.routes.Screen
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun HomeScreen(navController: NavHostController) {
    val imagesWithTitles =
        getImagesWithTitles(navController) // Replace this with your array of images and titles
    var language by remember {
        mutableStateOf("English")
    }

    val preferences = PreferenceManager.getDefaultSharedPreferences(context)
    val selectedLanguage = preferences.getString("selected_language", "")
    if (!selectedLanguage.isNullOrEmpty())
        language = selectedLanguage
    val act = LocalContext.current as Activity

    Scaffold(

        content = {
            Column {
                QuantityMenuSpinner(language) {
                    language = it

                    val languages = listOf("English" to "en", "Urdu" to "ur", "Pashto" to "ps")

                    val editor = preferences.edit()
                    editor.putString("selected_language", it)
                    editor.apply()
                    val lang = languages.find { it.first == language }?.second
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {

                        context.getSystemService(LocaleManager::class.java).applicationLocales =
                            LocaleList.forLanguageTags(lang)
                    } else {

                        AppCompatDelegate.setApplicationLocales(
                            LocaleListCompat.forLanguageTags(
                                lang
                            )
                        )

                        if (lang != null) {
                            langChange(lang, act)
                        }
                    }


                }
                ImageGrid(imagesWithTitles = imagesWithTitles)
            }
        }
    )
}


fun langChange(lang: String, activity: Activity) {
    val myLocale = Locale(lang)
    val res: Resources = context.resources
    val dm = res.displayMetrics
    val conf = res.configuration
    conf.locale = myLocale
    res.updateConfiguration(conf, dm)
    Locale.setDefault(myLocale)
    activity.onConfigurationChanged(conf)
}

private fun getImagesWithTitles(navController: NavHostController): List<ImageWithTitle> {
    // Replace this with your actual data
    return listOf(
        ImageWithTitle(context.getString(R.string.basic_skills_of_toilet), R.drawable.toiilet) {
            when (it) {
                Option.VOCABULARY -> navController.navigate(Screen.ToiletLearning.route)
                Option.ACTIVITY -> navController.navigate(Screen.ToiletActivity.route)

                Option.VIDEO -> navController.navigate(Screen.VideoActivity.routeWithId("0"))

            }
        },
        ImageWithTitle(context.getString(R.string.basic_skill_of_colors), R.drawable.pencil) {
            when (it) {
                Option.VOCABULARY -> navController.navigate(Screen.ColorsLearning.route)
                Option.ACTIVITY -> navController.navigate(Screen.ColorsActivity.route)

                Option.VIDEO -> navController.navigate(Screen.VideoActivity.routeWithId("1"))

            }
        },
        ImageWithTitle(
            context.getString(R.string.basic_skill_of_time),
            R.drawable.clock_icon_land
        ) {
            when (it) {
                Option.VOCABULARY -> navController.navigate(Screen.TimeLearning2.route)
                Option.ACTIVITY -> navController.navigate(Screen.TimeActivity.route)

                Option.VIDEO -> navController.navigate(Screen.VideoActivity.routeWithId("2"))

            }
        },
        ImageWithTitle(
            context.getString(R.string.basic_skill_of_rotation),
            R.drawable.spinner_fidget
        ) {
            when (it) {
                Option.VOCABULARY -> navController.navigate(Screen.RotationPecLearning.route)
                Option.ACTIVITY -> {
                    navController.navigate(Screen.RotationLearning.route)
                }

                Option.VIDEO -> navController.navigate(Screen.VideoActivity.routeWithId("3"))

            }
        },
        //    ImageWithTitle("Image 5", R.drawable.logo),
        //  ImageWithTitle("Image 6", R.drawable.logo),
        // Add more images and titles here
    )
}


@Composable
fun ImageGrid(imagesWithTitles: List<ImageWithTitle>) {


    LazyVerticalGrid(
        columns = GridCells.Fixed(1),
        // content padding
        contentPadding = PaddingValues(
            start = 4.dp,
            top = 8.dp,
            end = 4.dp,
            bottom = 8.dp
        ),
    ) {
        items(imagesWithTitles) { imageWithTitle ->
            ImageCard(imageWithTitle) {
                imageWithTitle.click.invoke(it)
            }

        }
    }
}


@Composable
fun QuantityMenuSpinner(
    selectedItem: String,
    onItemSelected: (String) -> Unit
) {

    /*  Row(
          modifier = Modifier
              .padding(8.dp)
              .wrapContentSize(),
          verticalAlignment = Alignment.CenterVertically
      ) {
          Text(selectedItem, fontWeight = FontWeight.Bold)

          Icon(
              painter = painterResource(id = R.drawable.baseline_arrow_drop_down_24),
              contentDescription = "drop down arrow",
              modifier = Modifier.padding(horizontal = 6.dp)
          )
      }*/
    val languages = arrayListOf("English", "Urdu", "Pashto")
    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.BottomEnd) {
        Spinner(
            modifier = Modifier.wrapContentSize(),
            dropDownModifier = Modifier.wrapContentSize(),
            items = languages,
            selectedItem = selectedItem,
            onItemSelected = onItemSelected,
            selectedItemFactory = { modifier, item ->
                Row(
                    modifier = modifier
                        .padding(8.dp)
                        .wrapContentSize(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(item, fontWeight = FontWeight.Bold)

                    Icon(
                        painter = painterResource(id = R.drawable.baseline_arrow_drop_down_24),
                        contentDescription = "drop down arrow",
                        modifier = Modifier.padding(horizontal = 6.dp)
                    )
                }
            },
            dropdownItemFactory = { item, _ ->
                Text(text = item)
            }
        )
    }
}