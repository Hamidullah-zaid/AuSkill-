package com.example.autizamproject.screens

import android.annotation.SuppressLint
import android.speech.tts.TextToSpeech
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import com.example.autizamproject.R
import com.example.autizamproject.components.ComposeLottieAnimation
import kotlinx.coroutines.delay
import kotlin.math.absoluteValue

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun RotationLearningScreen(tts: TextToSpeech) {
    // Replace this with your array of images and titles
    Scaffold(
        content = {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                val animId by remember { mutableIntStateOf(R.raw.sucess_anim) }

                val showAnimation = remember { mutableStateOf(false) }
                val goodJob = stringResource(R.string.good_job_spinner_is_rotating)

                if (showAnimation.value) {
                    ComposeLottieAnimation(Modifier.fillMaxSize(), animId)
                    tts.speak(
                        "$goodJob",
                        TextToSpeech.QUEUE_FLUSH,
                        null,
                        null
                    )

                }


                SpinningFidgetSpinner(R.drawable.spinner_fidget, showAnimation)


            }
        }
    )
}

@Composable
fun SpinningFidgetSpinner(
    spinnerImageResource: Int,
    showAnimation: MutableState<Boolean>,
    modifier: Modifier = Modifier

) {
    var rotationState by remember { mutableFloatStateOf(0f) }
    var angularVelocity by remember { mutableFloatStateOf(0f) }

    val density = LocalDensity.current.density

    val speedMultiplier = 0.2f
    val friction = 0.98f

    Image(
        painter = painterResource(id = spinnerImageResource),
        contentDescription = null,
        modifier = modifier
            .graphicsLayer(
                rotationZ = rotationState
            )
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, _, _ ->
                    angularVelocity = pan.x * density * speedMultiplier // Reverse the direction
                    showAnimation.value = true
                    Log.i("Rotation", "SpinningFidgetSpinner: ")
                }
            },
        contentScale = ContentScale.FillWidth
    )


    LaunchedEffect(Unit) {
        while (true) {
            if (angularVelocity.absoluteValue < 0.01f) {
                angularVelocity = 0f
                showAnimation.value = false
            } else {
                rotationState += angularVelocity
                angularVelocity *= friction
            }
            delay(16)

            Log.i("Rotation", "SpinningFidgetSpinner: stop")

        }
    }
}


@Composable
fun SpinningFidgetSpinner1(
    spinnerImageResource: Int,
    modifier: Modifier = Modifier
) {
    var rotationState by remember { mutableStateOf(0f) }
    var angularVelocity by remember { mutableStateOf(0f) }

    val density = LocalDensity.current.density
    val speedMultiplier = 0.2f
    val friction = 0.98f

    Image(
        painter = painterResource(id = spinnerImageResource),
        contentDescription = null,
        modifier = modifier
            .graphicsLayer(
                rotationZ = rotationState
            )
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, _, _ ->
                    angularVelocity = pan.x * density * speedMultiplier
                }
            },
        contentScale = ContentScale.FillBounds
    )

    LaunchedEffect(Unit) {
        while (true) {
            if (angularVelocity.absoluteValue < 0.01f) {
                angularVelocity = 0f
            } else {
                rotationState += angularVelocity
                angularVelocity *= if (angularVelocity > 0) friction else 1f / friction
            }
            delay(16)
        }
    }
}