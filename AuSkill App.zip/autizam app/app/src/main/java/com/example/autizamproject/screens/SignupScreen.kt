package com.example.autizamproject.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController

import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.OutlinedButton

import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.graphics.Color

import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.autizamproject.R
import com.example.autizamproject.routes.Screen
import com.example.autizamproject.viewmodels.SignupViewModel


@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SignupScreen(navController: NavHostController) {
    val signupViewModel: SignupViewModel = viewModel()

    val context = LocalContext.current

    Scaffold {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(6.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Form fields and validation logic

            Image(
                painter = painterResource(id = R.drawable.logo),
                contentDescription = "Logo",
                modifier = Modifier.size(90.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = signupViewModel.username,
                onValueChange = { signupViewModel.username = it },
                label = { Text(stringResource(R.string.username)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = signupViewModel.email,
                onValueChange = { signupViewModel.email = it },
                label = { Text(stringResource(id = R.string.email)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = !signupViewModel.isEmailValid.value!!
            )
            if (!signupViewModel.isEmailValid.value) {
                Text(
                    text = stringResource(id = R.string.invalid_email_format),
                    color = Color.Red,
                    modifier = Modifier.padding(start = 16.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = signupViewModel.password,
                onValueChange = { signupViewModel.password = it },
                label = { Text(stringResource(id = R.string.password)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                isError = !signupViewModel.isPasswordMatch.value
            )
            if (!signupViewModel.isPasswordMatch.value) {
                Text(
                    text = "Passwords do not match",
                    color = Color.Red,
                    modifier = Modifier.padding(start = 16.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = signupViewModel.confirmPassword,
                onValueChange = { signupViewModel.confirmPassword = it },
                label = { Text(stringResource(R.string.confirm_password)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                visualTransformation = PasswordVisualTransformation()
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = signupViewModel.age,
                onValueChange = { signupViewModel.age = it },
                label = { Text(stringResource(R.string.age)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            if (!signupViewModel.isAgeValid.value) {
                Text(
                    text = stringResource(R.string.invalid_age),
                    color = Color.Red,
                    modifier = Modifier.padding(start = 16.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = signupViewModel.phoneNumber,
                onValueChange = { signupViewModel.phoneNumber = it },
                label = { Text(stringResource(R.string.phone_number)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            if (!signupViewModel.isPhoneNumberValid.value!!) {
                Text(
                    text = stringResource(R.string.phone_number_is_required),
                    color = Color.Red,
                    modifier = Modifier.padding(start = 16.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    signupViewModel.signUpUser(
                        onSuccess = {
                            navController.popBackStack()
                            navController.navigate(Screen.Home.route) {
                                popUpTo(Screen.Home.route) {
                                    inclusive = true
                                }
                            }
                        },
                        onFailure = { errorMessage ->
                            // Handle failure and show an error message
                            Toast.makeText(context, errorMessage, Toast.LENGTH_SHORT).show()
                            Log.e("SignupScreen", errorMessage)
                        }
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = stringResource(id = R.string.sign_up))
            }

            OutlinedButton(onClick = {
                navController.popBackStack()
            }) {
                Text(text = stringResource(id = R.string.login))
            }
        }
    }
}

