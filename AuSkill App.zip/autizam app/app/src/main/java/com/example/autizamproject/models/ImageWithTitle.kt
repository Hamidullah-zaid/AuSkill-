package com.example.autizamproject.models

import com.example.autizamproject.components.Option

data class ImageWithTitle(val title: String, val imageResId: Int, val click: (Option) -> Unit)
