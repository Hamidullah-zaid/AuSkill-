package com.example.autizamproject.components

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role.Companion.Image
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.autizamproject.models.ImageWithTitle

@Composable
fun ImageCard(imageWithTitle: ImageWithTitle, callBack: (Option) -> Unit) {

    val showDialog = remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .padding(4.dp, bottom = 50.dp)
            .fillMaxWidth()
            .clickable {
                showDialog.value = true
            }
            .aspectRatio(1.5f)
    ) {

        if (showDialog.value) {
            ChooseOptionAlertDialog({
                showDialog.value = false
                callBack.invoke(it)
            },
                {
                    showDialog.value = false
                })
        }

        Box {
            Image(
                painter = painterResource(id = imageWithTitle.imageResId),
                contentDescription = imageWithTitle.title,
                contentScale = ContentScale.Inside,
                modifier = Modifier
                    .padding(bottom = 50.dp)
                    .fillMaxSize()

            )
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Red.copy(alpha = 0.5f))
                    .align(Alignment.BottomCenter)
                    .padding(8.dp)
            ) {
                Text(
                    text = imageWithTitle.title,
                    color = Color.White,
                    style = TextStyle(fontSize = 16.sp, textAlign = TextAlign.Center),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp)
                )
            }
        }
    }
}
