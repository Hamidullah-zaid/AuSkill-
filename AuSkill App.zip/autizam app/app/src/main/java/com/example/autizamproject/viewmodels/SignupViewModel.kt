package com.example.autizamproject.viewmodels

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.autizamproject.MyApp.Companion.context
import com.example.autizamproject.R
import com.example.autizamproject.models.UserData
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class SignupViewModel : ViewModel() {

    val auth = FirebaseAuth.getInstance()

    // State variables to hold user input
    var username by mutableStateOf("")
    var email by mutableStateOf("")
    var password by mutableStateOf("")
    var confirmPassword by mutableStateOf("")
    var age by mutableStateOf("")
    var phoneNumber by mutableStateOf("")

    // State variables for validation
    val isEmailValid = mutableStateOf(true)
    val isPasswordMatch = mutableStateOf(true)
    val isAgeValid = mutableStateOf(true)
    val isPhoneNumberValid = mutableStateOf(true)

    // Method to validate email format
    private fun validateEmail() {
        isEmailValid.value = android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    private fun validatePass() {
        isPasswordMatch.value = password.length >= 6
    }

    // Method to validate password match
    private fun validatePasswordMatch() {
        isPasswordMatch.value = password == confirmPassword
    }

    // Method to validate age
    private fun validateAge() {
        // You can add custom age validation logic here
        isAgeValid.value = age.isNotBlank() && age.toIntOrNull() != null && age.toInt() >= 18
    }

    // Method to validate phone number
    private fun validatePhoneNumber() {
        isPhoneNumberValid.value = phoneNumber.isNotBlank()
    }


    fun loginUser(onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        validateEmail()
        validatePass()

        if (!isEmailValid.value || !isPasswordMatch.value) {
            onFailure(context.getString(R.string.please_fill_in_all_the_required_fields_correctly))
            return
        }
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    onSuccess.invoke()
                } else {
                    // Handle sign-in failure
                    onFailure.invoke(task.exception?.message ?: "error")
                    // Display error message or handle errors accordingly
                }
            }

    }

    // Method to perform user signup
    fun signUpUser(onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        // Validate input fields before signing up
        validateEmail()
        validatePasswordMatch()
        validateAge()
        validatePhoneNumber()

        // If any validation fails, do not proceed with the signup
        if (!isEmailValid.value || !isPasswordMatch.value || !isAgeValid.value || !isPhoneNumberValid.value) {
            onFailure(context.getString(R.string.please_fill_in_all_the_required_fields_correctly))
            return
        }

        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val user = task.result?.user
                    user?.let {
                        val userData = UserData(
                            username = username,
                            email = email,
                            age = age.toInt(),
                            phoneNumber = phoneNumber
                        )

                        val db = FirebaseFirestore.getInstance()
                        db.collection("users").document(user.uid)
                            .set(userData)
                            .addOnSuccessListener {
                                onSuccess()
                            }
                            .addOnFailureListener { e ->
                                onFailure(context.getString(R.string.failed_to_store_user_data))
                            }
                    }
                } else {
                    onFailure("Sign-up failed. ${task.exception?.message}")
                }
            }
    }


}
