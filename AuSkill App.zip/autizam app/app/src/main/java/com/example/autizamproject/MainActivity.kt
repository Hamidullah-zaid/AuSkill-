package com.example.autizamproject

import android.app.LocaleManager
import android.os.Build
import android.os.Bundle
import android.os.LocaleList
import android.preference.PreferenceManager
import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.core.os.LocaleListCompat
import com.example.autizamproject.routes.NavHostManager
import com.example.autizamproject.screens.langChange
import com.example.autizamproject.ui.theme.AutizamProjectTheme
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var textToSpeech: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val preferences = PreferenceManager.getDefaultSharedPreferences(this)
        val selectedLanguage = preferences.getString("selected_language", "")

        val languages = listOf("English" to "en", "Urdu" to "ur", "Pashto" to "ps")

        val lang = languages.find { it.first == selectedLanguage }?.second
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {

            MyApp.context.getSystemService(LocaleManager::class.java).applicationLocales =
                LocaleList.forLanguageTags(lang)
        } else {

            AppCompatDelegate.setApplicationLocales(
                LocaleListCompat.forLanguageTags(
                    lang
                )
            )

            if (lang != null) {
                langChange(lang, this)
            }
        }




        textToSpeech = TextToSpeech(this, this)
        setContent {
            AutizamProjectTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    NavHostManager.SetupNavHost(textToSpeech)
                }
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = textToSpeech.setLanguage(Locale.US)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Handle language initialization failure
            }
        } else {
            // Handle TTS initialization failure
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    AutizamProjectTheme {
        Greeting("Android")
    }
}