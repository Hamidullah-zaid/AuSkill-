package com.example.autizamproject.screens

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.autizamproject.R
import com.example.autizamproject.components.ComposeLottieAnimation
import com.example.autizamproject.components.colors
import kotlin.random.Random

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun ColorsActivityScreen(textToSpeech: TextToSpeech) {
    // Replace this with your array of images and titles
    Scaffold(
        content = {
            ColorGameScreen(textToSpeech)
        }
    )
}

@Composable
fun ColorGameScreen(tts: TextToSpeech) {
    val context = LocalContext.current

    var correctColor by remember { mutableIntStateOf(randomColor()) }
    var wrongColor by remember { mutableIntStateOf(randomColor()) }
    var showAnimation by remember { mutableStateOf(false) }
    var animId by remember { mutableIntStateOf(R.raw.sucess_anim) }

    while (wrongColor == correctColor) {
        wrongColor = randomColor()
        showAnimation = false
    }

    Box {


        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFEBEBCB))
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val chose = stringResource(id = R.string.choose)
            val color = stringResource(id = R.string.color)
            val chosenColorName = colors.find { it.second == correctColor }?.first ?: "___"
            Text("$chose $chosenColorName $color", style = MaterialTheme.typography.headlineLarge)
            if (!showAnimation)
                tts.speak(
                    "$chose $chosenColorName $color",
                    TextToSpeech.QUEUE_FLUSH,
                    null,
                    null
                )


            Spacer(modifier = Modifier.height(16.dp))
            val goodJob = stringResource(R.string.good_job_you_have_chose_correct_one)
            val wrongSelection = stringResource(R.string.ohh_no_you_chose_wrong_try_again)
            val colorSelected: (Int) -> Unit = { color ->
                if (color == correctColor) {
                    showAnimation = true
                    animId = R.raw.sucess_anim
                    tts.speak(
                        goodJob,
                        TextToSpeech.QUEUE_FLUSH,
                        null,
                        null
                    )

                    Handler(Looper.getMainLooper()).postDelayed({
                        showAnimation = false
                        correctColor = randomColor()

                    }, 2500)
                } else {
                    showAnimation = true
                    animId = R.raw.try_again
                    tts.speak(
                        wrongSelection,
                        TextToSpeech.QUEUE_FLUSH,
                        null,
                        null
                    )

                    Handler(Looper.getMainLooper()).postDelayed({
                        showAnimation = false
                    }, 2500)
                }

            }
            val ran = Random.nextBoolean()
            ColorCard(color = if (ran) correctColor else wrongColor, colorSelected)

            Spacer(modifier = Modifier.height(40.dp))

            ColorCard(color = if (!ran) correctColor else wrongColor, colorSelected)
        }

        if (showAnimation) {
            ComposeLottieAnimation(Modifier.fillMaxSize(), animId)
        }
    }
}


@Composable
fun ColorCard(color: Int, onClick: (Int) -> Unit) {
    Card(
        modifier = Modifier
            .size(200.dp)
            .clickable { onClick(color) }
    ) {

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(color)),
            contentAlignment = Alignment.Center
        ) {

        }
    }
}

fun randomColor(): Int {
    val randomIndex = Random.nextInt(colors.size)
    return colors[randomIndex].second
}


