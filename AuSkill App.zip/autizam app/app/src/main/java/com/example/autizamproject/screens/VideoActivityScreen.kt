package com.example.autizamproject.screens

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.rememberAsyncImagePainter
import com.example.autizamproject.R
import com.example.autizamproject.components.timeVideos
import com.example.autizamproject.ui.theme.dialogueBg
import com.example.autizamproject.viewmodels.VideoTitleViewModel


@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoActivityScreen(list: List<String>) {
    // ... Your SplashScreen code ...
    Scaffold {
        Column(
            modifier = Modifier
                .fillMaxSize(),
            verticalArrangement = Arrangement.SpaceAround,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = stringResource(R.string.learning_from_video),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.headlineLarge,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            )


            //     VideoThumbnailView("it")
            val viewModel: VideoTitleViewModel = viewModel()
            LazyColumn(content = {
                items(list) {
                    VideoThumbnailView(it, viewModel = viewModel)
                }
            })


        }
    }
}


@SuppressLint("CoroutineCreationDuringComposition")
@Composable
fun VideoThumbnailView(
    videoId: String,
    viewModel: VideoTitleViewModel
) {


    /*    var title by remember {
            mutableStateOf("")
        }*/
    val thumbnailul = "https://img.youtube.com/vi/$videoId/hqdefault.jpg";

    //val coroutineScope = rememberCoroutineScope()
    // This LaunchedEffect will execute the coroutine only when videoId changes
    val title = viewModel.getTitle(videoId)
    // val thumbnailUrl = "https://img.youtube.com/vi/$videoId/hqdefault.jpg"

    LaunchedEffect(videoId) {
        if (title.isEmpty()) {
            viewModel.fetchAndSaveTitle(videoId)
        }
    }

    /*

    coroutineScope.launch(Dispatchers.IO) {
        getTitleQuietly(videoId) {
            title = it
        }
    }*/

    //   Glide.with(context).load(thumbnailul).into(holder.iv_thumbnail);
    val launcher =
        rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
            // Handle the result here if needed
        }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp)
            .background(dialogueBg, RoundedCornerShape(12.dp))
            .clickable {

                val videoUrl = "https://www.youtube.com/watch?v=$videoId"

                //   val videoUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"

                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(videoUrl))
                launcher.launch(intent)

                //  opened.value = true
            }

    ) {
        // Video thumbnail


        Image(
            painter = rememberAsyncImagePainter(model = thumbnailul),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .aspectRatio(16f / 9f)
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Video title
        Text(
            text = title,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        )

        Spacer(modifier = Modifier.height(4.dp))

    }
}


