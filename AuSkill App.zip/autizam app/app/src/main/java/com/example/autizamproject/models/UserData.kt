package com.example.autizamproject.models

data class UserData(
    val username: String,
    val email: String,
    val age: Int,
    val phoneNumber: String
)
