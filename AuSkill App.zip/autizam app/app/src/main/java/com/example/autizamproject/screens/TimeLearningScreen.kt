package com.example.autizamproject.screens

import android.annotation.SuppressLint
import android.util.Log
import android.widget.GridLayout
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.autizamproject.R
import com.example.autizamproject.components.pagerAnimation
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun TimeLearningScreen(navController: NavHostController) {
    val context = LocalContext.current
    // Replace this with your array of images and titles
    Scaffold(
        content = {
            AnimatedViewPagerTime()

        }
    )
}

@Composable
fun AnalogClock(time: Long, modifier: Modifier) {
    val context = LocalContext.current
    val density = LocalDensity.current.density
    val clockSize = (150 * density).dp


    Log.i("TimeNow", "AnalogClock: ${Date(time).time}")

    val clockFaceDrawable = painterResource(id = R.drawable.clock_face)
    val smallHandDrawable = painterResource(id = R.drawable.hand_small)
    // val bigHandDrawable = painterResource(id = R.drawable.clock_hand_big)


    // Calculate rotation angles for the clock hands based on the 'time' input
    val rotationAngleSmallHand = calculateRotationAngle(time, HandType.MINUTE)
    val rotationAngleBigHand = calculateRotationAngle(time, HandType.HOUR)
    Box(modifier = modifier) {


        // Draw the clock face using Image composable
        Image(
            clockFaceDrawable,
            contentDescription = null,
            modifier = Modifier.size(clockSize)
        )

        // Draw the clock hands using Image composable with rotation and positioning
        Image(
            smallHandDrawable,
            contentDescription = null,
            modifier = Modifier
                .size(clockSize)
                .rotate(rotationAngleSmallHand),
            contentScale = ContentScale.Fit

        )

        Image(
            smallHandDrawable,
            contentDescription = null,
            modifier = Modifier
                .size(clockSize)
                .rotate(rotationAngleBigHand),
            contentScale = ContentScale.Fit
        )

    }
}

fun calculateRotationAngle(time: Long, handType: HandType): Float {
    val calendar = Calendar.getInstance().apply {
        timeInMillis = time
    }

    val hour = calendar.get(Calendar.HOUR_OF_DAY) % 12
    val minute = calendar.get(Calendar.MINUTE)
    val second = calendar.get(Calendar.SECOND)

    return when (handType) {
        HandType.HOUR -> 360f * (hour + minute / 60f) / 12f
        HandType.MINUTE -> 360f * (minute + second / 60f) / 60f
        HandType.SECOND -> 360f * second / 60f
    }
}

enum class HandType {
    HOUR,
    MINUTE,
    SECOND
}


@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AnimatedViewPagerTime(
    modifier: Modifier = Modifier,
    resetKey: Float = 0f, // Add a resetKey parameter

) {
    val context = LocalContext.current

    // Use the resetKey to recreate the pager state and current page index
    val pagerState =
        rememberPagerState(initialPage = 0, initialPageOffsetFraction = resetKey) { 144 }
    var currentPageIndex by remember { mutableIntStateOf(0) }

    val hapticFeedback = LocalHapticFeedback.current

    val coroutineScope = rememberCoroutineScope()



    LaunchedEffect(Unit) {

        snapshotFlow { pagerState.currentPage }.collect { currentPage ->
            if (currentPageIndex != currentPage) {
                hapticFeedback.performHapticFeedback(hapticFeedbackType = HapticFeedbackType.LongPress)
                currentPageIndex = currentPage
            }
            // Anything to be triggered by page-change can be done here
        }
    }
    var currentTime = 1692385200000
    val interval = 300000 // in seconds

    HorizontalPager(
        modifier = modifier,
        state = pagerState,
        contentPadding = PaddingValues(horizontal = 90.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {


        AnalogClock(
            modifier = Modifier
                .fillMaxSize()
                .aspectRatio(1f)
                .pagerAnimation(pagerState, it), time = currentTime + (interval * it)
        )
        //  currentTime += interval


    }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 20.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.Bottom
    ) {

        Button(onClick = {

            currentPageIndex -= 12
            if (currentPageIndex < 0)
                currentPageIndex = 0
            coroutineScope.launch {
                pagerState.animateScrollToPage(currentPageIndex) // Scroll to the updated page
            }


        }) {
            Text(text = stringResource(R.string.back_12))
        }
        Spacer(modifier = Modifier.width(20.dp))
        Button(onClick = {

            currentPageIndex += 12
            if (currentPageIndex > 144)
                currentPageIndex = 144
            coroutineScope.launch {
                pagerState.animateScrollToPage(currentPageIndex) // Scroll to the updated page
            }


        }) {
            Text(text = stringResource(R.string.move_12))
        }
    }

}


@Composable
fun AnalogClockGrid() {
    val interval = 300000 // in seconds

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        // content padding
        contentPadding = PaddingValues(
            start = 4.dp,
            top = 8.dp,
            end = 4.dp,
            bottom = 8.dp
        ),
    ) {
        var currentTime = 1692385200000
        repeat(144) { // 12 hours * 60 minutes / 5 minutes interval
            item {
                AnalogClock(
                    time = currentTime, modifier = Modifier
                        .fillMaxSize()
                        .aspectRatio(0.5f)
                    //.pagerAnimation(pagerState, it)
                )
                currentTime += interval
            }
        }
    }
}
