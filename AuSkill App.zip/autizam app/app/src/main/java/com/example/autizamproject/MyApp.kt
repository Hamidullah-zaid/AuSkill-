package com.example.autizamproject

import android.app.Activity
import android.app.Application
import android.preference.PreferenceManager
import androidx.compose.ui.platform.LocalContext
import com.example.autizamproject.screens.langChange

class MyApp : Application() {

    companion object {
        lateinit var context: Application
    }

    override fun onCreate() {
        super.onCreate()
        context = this
        val languages = listOf("English" to "en", "Urdu" to "ur", "Pashto" to "ps")

        val preferences = PreferenceManager.getDefaultSharedPreferences(this)
        val selectedLanguage = preferences.getString("selected_language", "")
        val lang = languages.find { it.first == selectedLanguage }?.second
        if (selectedLanguage?.isEmpty() != true) {
            // selectedLocale is the user's chosen locale
            if (lang != null) {
               // langChange(lang, this)
            }
        }

    }
}