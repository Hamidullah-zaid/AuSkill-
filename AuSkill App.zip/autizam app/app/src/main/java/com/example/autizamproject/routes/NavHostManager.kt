package com.example.autizamproject.routes

import android.speech.tts.TextToSpeech
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.autizamproject.components.colorsVideos
import com.example.autizamproject.components.rotationVideos
import com.example.autizamproject.components.timeVideos
import com.example.autizamproject.components.toiletVideos
import com.example.autizamproject.screens.ColorsActivityScreen
import com.example.autizamproject.screens.ColorsLearningScreen
import com.example.autizamproject.screens.HomeScreen
import com.example.autizamproject.screens.LoginScreen
import com.example.autizamproject.screens.RotationLearningPecScreen
import com.example.autizamproject.screens.RotationLearningScreen
import com.example.autizamproject.screens.SignupScreen
import com.example.autizamproject.screens.SplashScreen
import com.example.autizamproject.screens.TimeActivityScreen
import com.example.autizamproject.screens.TimeLearningScreen
import com.example.autizamproject.screens.TimeLearningScreen2
import com.example.autizamproject.screens.ToiletLearningScreen
import com.example.autizamproject.screens.VideoActivityScreen
import com.example.autizamproject.screens.WashroomActivityScreen

object NavHostManager {
    @Composable
    fun SetupNavHost(textToSpeech: TextToSpeech) {
        val navController = rememberNavController()
        NavHost(navController = navController, startDestination = Screen.Splash.route) {
            composable(Screen.Splash.route) {
                SplashScreen(navController = navController)
            }
            composable(Screen.Login.route) {
                LoginScreen(navController = navController)
            }
            composable(Screen.Signup.route) {
                SignupScreen(navController = navController)
            }
            composable(Screen.Home.route) {
                HomeScreen(navController = navController)
            }

            composable(Screen.TimeLearning.route) {
                TimeLearningScreen(navController = navController)
            }

            composable(Screen.TimeActivity.route) {
                TimeActivityScreen(textToSpeech)
            }
            composable(Screen.TimeLearning2.route) {
                TimeLearningScreen2(textToSpeech)
            }
            composable(Screen.ToiletLearning.route) {
                ToiletLearningScreen(textToSpeech)
            }

            composable(Screen.RotationLearning.route) {
                RotationLearningScreen(textToSpeech)
            }

            composable(Screen.RotationPecLearning.route) {
                RotationLearningPecScreen(textToSpeech)
            }
            composable(Screen.ColorsLearning.route) {
                ColorsLearningScreen(navController = navController, textToSpeech)
            }

            composable(Screen.ColorsActivity.route) {
                ColorsActivityScreen(textToSpeech)
            }
            composable(Screen.ToiletActivity.route) {
                WashroomActivityScreen(textToSpeech)
            }


            composable(Screen.VideoActivity.route) {

                val list: List<String> = when (it.arguments?.getString("id")) {
                    "0" -> toiletVideos
                    "1" -> colorsVideos
                    "2" -> timeVideos
                    "3" -> rotationVideos
                    else -> toiletVideos
                }


                VideoActivityScreen(list)
            }
        }
    }
}
