package com.example.autizamproject.screens

import android.annotation.SuppressLint
import android.speech.tts.TextToSpeech
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.autizamproject.components.ColorCard
import com.example.autizamproject.components.colors
import com.example.autizamproject.components.pagerAnimation

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun ColorsLearningScreen(navController: NavHostController, textToSpeech: TextToSpeech) {
    // Replace this with your array of images and titles
    Scaffold(
        content = {
            AnimatedViewPager(
                modifier = Modifier
                    .background(Color(0xFFEBEBCB))
                    .fillMaxWidth(), textToSpeech
            )
        }
    )
}


@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AnimatedViewPager(
    modifier: Modifier = Modifier,
    tts: TextToSpeech,
    resetKey: Float = 0f, // Add a resetKey parameter


) {
    // Use the resetKey to recreate the pager state and current page index
    val pagerState =
        rememberPagerState(initialPage = 0, initialPageOffsetFraction = resetKey) { colors.size }
    var currentPageIndex by remember { mutableStateOf(0) }

    val hapticFeedback = LocalHapticFeedback.current
    LaunchedEffect(Unit) {
        snapshotFlow { pagerState.currentPage }.collect { currentPage ->
            if (currentPageIndex != currentPage) {
                hapticFeedback.performHapticFeedback(hapticFeedbackType = HapticFeedbackType.LongPress)
                currentPageIndex = currentPage
            }
            // Anything to be triggered by page-change can be done here
        }
    }

    HorizontalPager(
        modifier = modifier,
        state = pagerState,
        contentPadding = PaddingValues(horizontal = 90.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {

        ColorCard(
            modifier = Modifier
                .fillMaxSize()
                .aspectRatio(0.5f)
                .pagerAnimation(pagerState, it), colors[it]
        ) {
            tts.speak(colors[it].first, TextToSpeech.QUEUE_FLUSH, null, null)
        }
    }
}


